/********************************************************************************
** Form generated from reading UI file 'tabpage.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TABPAGE_H
#define UI_TABPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyTabPage
{
public:
    QVBoxLayout *verticalLayout_2;
    QLabel *label_4;
    QComboBox *columnChoice_2;
    QPushButton *pushButton;
    QLabel *label;
    QTextBrowser *textFile;
    QLabel *label_3;
    QComboBox *columnChoice;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout;
    QPushButton *runButton;
    QPushButton *pauseButton;
    QPushButton *instantButton;

    void setupUi(QWidget *MyTabPage)
    {
        if (MyTabPage->objectName().isEmpty())
            MyTabPage->setObjectName("MyTabPage");
        MyTabPage->resize(403, 579);
        verticalLayout_2 = new QVBoxLayout(MyTabPage);
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_4 = new QLabel(MyTabPage);
        label_4->setObjectName("label_4");

        verticalLayout_2->addWidget(label_4);

        columnChoice_2 = new QComboBox(MyTabPage);
        columnChoice_2->addItem(QString());
        columnChoice_2->addItem(QString());
        columnChoice_2->addItem(QString());
        columnChoice_2->addItem(QString());
        columnChoice_2->setObjectName("columnChoice_2");

        verticalLayout_2->addWidget(columnChoice_2);

        pushButton = new QPushButton(MyTabPage);
        pushButton->setObjectName("pushButton");

        verticalLayout_2->addWidget(pushButton);

        label = new QLabel(MyTabPage);
        label->setObjectName("label");

        verticalLayout_2->addWidget(label);

        textFile = new QTextBrowser(MyTabPage);
        textFile->setObjectName("textFile");
        textFile->setMaximumSize(QSize(16777215, 70));

        verticalLayout_2->addWidget(textFile);

        label_3 = new QLabel(MyTabPage);
        label_3->setObjectName("label_3");

        verticalLayout_2->addWidget(label_3);

        columnChoice = new QComboBox(MyTabPage);
        columnChoice->setObjectName("columnChoice");

        verticalLayout_2->addWidget(columnChoice);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        runButton = new QPushButton(MyTabPage);
        runButton->setObjectName("runButton");
        runButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));

        verticalLayout->addWidget(runButton);

        pauseButton = new QPushButton(MyTabPage);
        pauseButton->setObjectName("pauseButton");
        pauseButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));

        verticalLayout->addWidget(pauseButton);

        instantButton = new QPushButton(MyTabPage);
        instantButton->setObjectName("instantButton");
        instantButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));

        verticalLayout->addWidget(instantButton);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(MyTabPage);

        QMetaObject::connectSlotsByName(MyTabPage);
    } // setupUi

    void retranslateUi(QWidget *MyTabPage)
    {
        MyTabPage->setWindowTitle(QCoreApplication::translate("MyTabPage", "Form", nullptr));
        label_4->setText(QCoreApplication::translate("MyTabPage", "choose algortihm:", nullptr));
        columnChoice_2->setItemText(0, QString());
        columnChoice_2->setItemText(1, QCoreApplication::translate("MyTabPage", "Delta - Huffman", nullptr));
        columnChoice_2->setItemText(2, QCoreApplication::translate("MyTabPage", "Delta - Sprintz", nullptr));
        columnChoice_2->setItemText(3, QCoreApplication::translate("MyTabPage", "FIRE - Sprintz", nullptr));

        pushButton->setText(QCoreApplication::translate("MyTabPage", "choose file", nullptr));
        label->setText(QCoreApplication::translate("MyTabPage", "filename:", nullptr));
        textFile->setHtml(QCoreApplication::translate("MyTabPage", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        label_3->setText(QCoreApplication::translate("MyTabPage", "choose datastream:", nullptr));
        runButton->setText(QCoreApplication::translate("MyTabPage", "Run", nullptr));
        pauseButton->setText(QCoreApplication::translate("MyTabPage", "pause/resume", nullptr));
        instantButton->setText(QCoreApplication::translate("MyTabPage", "Instant", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MyTabPage: public Ui_MyTabPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TABPAGE_H
