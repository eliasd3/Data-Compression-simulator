/********************************************************************************
** Form generated from reading UI file 'visualisation.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VISUALISATION_H
#define UI_VISUALISATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QGridLayout *gridLayout;
    QLabel *label_14;
    QLabel *label_12;
    QLabel *label_13;
    QCustomPlot *dataplot_4;
    QCustomPlot *compressedplot_4;
    QCustomPlot *decompressedplot_4;
    QScrollArea *scrollArea_4;
    QWidget *scrollAreaWidgetContents_5;
    QGridLayout *gridLayout_9;
    QLabel *compressedDataView_4;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QLabel *labelResults1;
    QSpacerItem *verticalSpacer_3;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName("Form");
        Form->resize(879, 219);
        gridLayout = new QGridLayout(Form);
        gridLayout->setObjectName("gridLayout");
        label_14 = new QLabel(Form);
        label_14->setObjectName("label_14");
        label_14->setMinimumSize(QSize(150, 0));
        label_14->setMaximumSize(QSize(16777215, 20));

        gridLayout->addWidget(label_14, 0, 0, 1, 1);

        label_12 = new QLabel(Form);
        label_12->setObjectName("label_12");
        label_12->setMinimumSize(QSize(150, 0));

        gridLayout->addWidget(label_12, 0, 1, 1, 1);

        label_13 = new QLabel(Form);
        label_13->setObjectName("label_13");
        label_13->setMinimumSize(QSize(150, 0));

        gridLayout->addWidget(label_13, 0, 2, 1, 1);

        dataplot_4 = new QCustomPlot(Form);
        dataplot_4->setObjectName("dataplot_4");

        gridLayout->addWidget(dataplot_4, 1, 0, 1, 1);

        compressedplot_4 = new QCustomPlot(Form);
        compressedplot_4->setObjectName("compressedplot_4");

        gridLayout->addWidget(compressedplot_4, 1, 1, 1, 1);

        decompressedplot_4 = new QCustomPlot(Form);
        decompressedplot_4->setObjectName("decompressedplot_4");

        gridLayout->addWidget(decompressedplot_4, 1, 2, 1, 1);

        scrollArea_4 = new QScrollArea(Form);
        scrollArea_4->setObjectName("scrollArea_4");
        scrollArea_4->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(scrollArea_4->sizePolicy().hasHeightForWidth());
        scrollArea_4->setSizePolicy(sizePolicy);
        scrollArea_4->setMaximumSize(QSize(16777215, 43));
        scrollArea_4->setLayoutDirection(Qt::RightToLeft);
        scrollArea_4->setStyleSheet(QString::fromUtf8("QScrollBar:horizontal {\n"
"    height: 11px;\n"
"    margin: 3px 3px 3px 3px;\n"
"    border: 3px transparent #2A2929;\n"
"    border-radius: 1.5px;\n"
"    background-color: gray;    /* #2A2929; */\n"
"}\n"
"\n"
"QScrollBar::handle:horizontal {\n"
"    background-color: green;      /* #605F5F; */\n"
"    min-width: 5px;\n"
"    border-radius: 1.5px;\n"
"    border: 1px solid transparent; /* Set a transparent border */\n"
"}\n"
"\n"
"QScrollBar::add-line:horizontal,\n"
"QScrollBar::sub-line:horizontal {\n"
"    border: none; /* Remove borders for add and sub lines */\n"
"}\n"
"\n"
"    QScrollBar::add-line:horizontal\n"
"    {\n"
"        margin: 0px 3px 0px 3px;\n"
"        border-image: url(:/qss_icons/rc/right_arrow_disabled.png);\n"
"        width: 10px;\n"
"        height: 10px;\n"
"        subcontrol-position: right;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::sub-line:horizontal\n"
"    {\n"
"        margin: 0px 3px 0px 3px;\n"
"        border-image: url(:/qss_icons/rc/lef"
                        "t_arrow_disabled.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: left;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::add-line:horizontal:hover,QScrollBar::add-line:horizontal:on\n"
"    {\n"
"        border-image: url(:/qss_icons/rc/right_arrow.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: right;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"\n"
"    QScrollBar::sub-line:horizontal:hover, QScrollBar::sub-line:horizontal:on\n"
"    {\n"
"        border-image: url(:/qss_icons/rc/left_arrow.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: left;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::up-arrow:horizontal, QScrollBar::down-arrow:horizontal\n"
"    {\n"
"        background: none;\n"
"    }\n"
"\n"
"\n"
"    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal\n"
"    {\n"
"        background: none;\n"
"    "
                        "}\n"
"\n"
"    QScrollBar:vertical\n"
"    {\n"
"        background-color: #2A2929;\n"
"        width: 15px;\n"
"        margin: 15px 3px 15px 3px;\n"
"        border: 1px transparent #2A2929;\n"
"        border-radius: 4px;\n"
"    }\n"
"\n"
"    QScrollBar::handle:vertical\n"
"    {\n"
"        background-color: red;         /* #605F5F; */\n"
"        min-height: 5px;\n"
"        border-radius: 4px;\n"
"    }\n"
"\n"
"    QScrollBar::sub-line:vertical\n"
"    {\n"
"        margin: 3px 0px 3px 0px;\n"
"        border-image: url(:/qss_icons/rc/up_arrow_disabled.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: top;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::add-line:vertical\n"
"    {\n"
"        margin: 3px 0px 3px 0px;\n"
"        border-image: url(:/qss_icons/rc/down_arrow_disabled.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: bottom;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"  "
                        "  QScrollBar::sub-line:vertical:hover,QScrollBar::sub-line:vertical:on\n"
"    {\n"
"        border-image: url(:/qss_icons/rc/up_arrow.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: top;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::add-line:vertical:hover, QScrollBar::add-line:vertical:on\n"
"    {\n"
"        border-image: url(:/qss_icons/rc/down_arrow.png);\n"
"        height: 10px;\n"
"        width: 10px;\n"
"        subcontrol-position: bottom;\n"
"        subcontrol-origin: margin;\n"
"    }\n"
"\n"
"    QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical\n"
"    {\n"
"        background: none;\n"
"    }\n"
"\n"
"    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical\n"
"    {\n"
"        background: none;\n"
"    }"));
        scrollArea_4->setFrameShape(QFrame::StyledPanel);
        scrollArea_4->setFrameShadow(QFrame::Plain);
        scrollArea_4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollArea_4->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName("scrollAreaWidgetContents_5");
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 642, 41));
        gridLayout_9 = new QGridLayout(scrollAreaWidgetContents_5);
        gridLayout_9->setObjectName("gridLayout_9");
        compressedDataView_4 = new QLabel(scrollAreaWidgetContents_5);
        compressedDataView_4->setObjectName("compressedDataView_4");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(compressedDataView_4->sizePolicy().hasHeightForWidth());
        compressedDataView_4->setSizePolicy(sizePolicy1);
        compressedDataView_4->setMaximumSize(QSize(16777215, 11));
        compressedDataView_4->setLayoutDirection(Qt::RightToLeft);
        compressedDataView_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        compressedDataView_4->setWordWrap(false);

        gridLayout_9->addWidget(compressedDataView_4, 0, 0, 1, 1);

        scrollArea_4->setWidget(scrollAreaWidgetContents_5);

        gridLayout->addWidget(scrollArea_4, 2, 0, 1, 3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName("verticalLayout");
        label_4 = new QLabel(Form);
        label_4->setObjectName("label_4");

        verticalLayout->addWidget(label_4);

        labelResults1 = new QLabel(Form);
        labelResults1->setObjectName("labelResults1");

        verticalLayout->addWidget(labelResults1);

        verticalSpacer_3 = new QSpacerItem(20, 80, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout->addItem(verticalSpacer_3);


        gridLayout->addLayout(verticalLayout, 1, 3, 1, 1);


        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QCoreApplication::translate("Form", "Form", nullptr));
        label_14->setText(QCoreApplication::translate("Form", "Original data:", nullptr));
        label_12->setText(QCoreApplication::translate("Form", "Compressed data:", nullptr));
        label_13->setText(QCoreApplication::translate("Form", "Decompressed data:", nullptr));
        compressedDataView_4->setText(QString());
        label_4->setText(QCoreApplication::translate("Form", "Compression Ratio:", nullptr));
        labelResults1->setText(QCoreApplication::translate("Form", "1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VISUALISATION_H
