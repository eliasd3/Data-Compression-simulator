/****************************************************************************
** Meta object code from reading C++ file 'plotpertab.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../projectwithqmake20_04/projectwithqmake/plotpertab.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'plotpertab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSplotPerTabENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSplotPerTabENDCLASS = QtMocHelpers::stringData(
    "plotPerTab",
    "onDecompressedplotDoubleclick",
    "",
    "onCompressedplotDoubleclick",
    "onDataplotDoubleClick"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSplotPerTabENDCLASS_t {
    uint offsetsAndSizes[10];
    char stringdata0[11];
    char stringdata1[30];
    char stringdata2[1];
    char stringdata3[28];
    char stringdata4[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSplotPerTabENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSplotPerTabENDCLASS_t qt_meta_stringdata_CLASSplotPerTabENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "plotPerTab"
        QT_MOC_LITERAL(11, 29),  // "onDecompressedplotDoubleclick"
        QT_MOC_LITERAL(41, 0),  // ""
        QT_MOC_LITERAL(42, 27),  // "onCompressedplotDoubleclick"
        QT_MOC_LITERAL(70, 21)   // "onDataplotDoubleClick"
    },
    "plotPerTab",
    "onDecompressedplotDoubleclick",
    "",
    "onCompressedplotDoubleclick",
    "onDataplotDoubleClick"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSplotPerTabENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   32,    2, 0x08,    1 /* Private */,
       3,    0,   33,    2, 0x08,    2 /* Private */,
       4,    0,   34,    2, 0x08,    3 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject plotPerTab::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSplotPerTabENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSplotPerTabENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSplotPerTabENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<plotPerTab, std::true_type>,
        // method 'onDecompressedplotDoubleclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onCompressedplotDoubleclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onDataplotDoubleClick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void plotPerTab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<plotPerTab *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onDecompressedplotDoubleclick(); break;
        case 1: _t->onCompressedplotDoubleclick(); break;
        case 2: _t->onDataplotDoubleClick(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *plotPerTab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *plotPerTab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSplotPerTabENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int plotPerTab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 3;
    }
    return _id;
}
QT_WARNING_POP
