/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../projectwithqmake20_04/projectwithqmake/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "handleDeltaCompressedData",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "decompressedData",
    "tabNumber",
    "handleHuffmanData",
    "vector<string>",
    "encodedValues",
    "decodedValues",
    "handleFireUpdate",
    "handleRatiosUpdates",
    "ratio1",
    "onButtonClicked",
    "onFileAddActionTriggered",
    "on_linemsall_returnPressed",
    "on_runButtonMain_clicked",
    "on_pauseButtonMain_clicked",
    "on_instantButtonMain_clicked",
    "on_pushButton_clicked",
    "on_pushButton_2_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[11];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[11];
    char stringdata5[15];
    char stringdata6[17];
    char stringdata7[10];
    char stringdata8[18];
    char stringdata9[15];
    char stringdata10[14];
    char stringdata11[14];
    char stringdata12[17];
    char stringdata13[20];
    char stringdata14[7];
    char stringdata15[16];
    char stringdata16[25];
    char stringdata17[27];
    char stringdata18[25];
    char stringdata19[27];
    char stringdata20[29];
    char stringdata21[22];
    char stringdata22[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 25),  // "handleDeltaCompressedData"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 14),  // "vector<double>"
        QT_MOC_LITERAL(53, 10),  // "dataStream"
        QT_MOC_LITERAL(64, 14),  // "compressedData"
        QT_MOC_LITERAL(79, 16),  // "decompressedData"
        QT_MOC_LITERAL(96, 9),  // "tabNumber"
        QT_MOC_LITERAL(106, 17),  // "handleHuffmanData"
        QT_MOC_LITERAL(124, 14),  // "vector<string>"
        QT_MOC_LITERAL(139, 13),  // "encodedValues"
        QT_MOC_LITERAL(153, 13),  // "decodedValues"
        QT_MOC_LITERAL(167, 16),  // "handleFireUpdate"
        QT_MOC_LITERAL(184, 19),  // "handleRatiosUpdates"
        QT_MOC_LITERAL(204, 6),  // "ratio1"
        QT_MOC_LITERAL(211, 15),  // "onButtonClicked"
        QT_MOC_LITERAL(227, 24),  // "onFileAddActionTriggered"
        QT_MOC_LITERAL(252, 26),  // "on_linemsall_returnPressed"
        QT_MOC_LITERAL(279, 24),  // "on_runButtonMain_clicked"
        QT_MOC_LITERAL(304, 26),  // "on_pauseButtonMain_clicked"
        QT_MOC_LITERAL(331, 28),  // "on_instantButtonMain_clicked"
        QT_MOC_LITERAL(360, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(382, 23)   // "on_pushButton_2_clicked"
    },
    "MainWindow",
    "handleDeltaCompressedData",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "decompressedData",
    "tabNumber",
    "handleHuffmanData",
    "vector<string>",
    "encodedValues",
    "decodedValues",
    "handleFireUpdate",
    "handleRatiosUpdates",
    "ratio1",
    "onButtonClicked",
    "onFileAddActionTriggered",
    "on_linemsall_returnPressed",
    "on_runButtonMain_clicked",
    "on_pauseButtonMain_clicked",
    "on_instantButtonMain_clicked",
    "on_pushButton_clicked",
    "on_pushButton_2_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    4,   86,    2, 0x0a,    1 /* Public */,
       8,    5,   95,    2, 0x0a,    6 /* Public */,
      12,    2,  106,    2, 0x0a,   12 /* Public */,
      13,    2,  111,    2, 0x0a,   15 /* Public */,
      15,    0,  116,    2, 0x0a,   18 /* Public */,
      16,    0,  117,    2, 0x08,   19 /* Private */,
      17,    0,  118,    2, 0x08,   20 /* Private */,
      18,    0,  119,    2, 0x08,   21 /* Private */,
      19,    0,  120,    2, 0x08,   22 /* Private */,
      20,    0,  121,    2, 0x08,   23 /* Private */,
      21,    0,  122,    2, 0x08,   24 /* Private */,
      22,    0,  123,    2, 0x08,   25 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3, 0x80000000 | 3, QMetaType::Int,    4,    5,    6,    7,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 9, 0x80000000 | 3, 0x80000000 | 3, QMetaType::Int,    4,    5,   10,   11,    7,
    QMetaType::Void, 0x80000000 | 9, QMetaType::Int,    5,    7,
    QMetaType::Void, QMetaType::Double, QMetaType::Int,   14,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'handleDeltaCompressedData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'handleHuffmanData'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<string>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'handleFireUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<string>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'handleRatiosUpdates'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onFileAddActionTriggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_linemsall_returnPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_runButtonMain_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pauseButtonMain_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_instantButtonMain_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->handleDeltaCompressedData((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[4]))); break;
        case 1: _t->handleHuffmanData((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<string>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[5]))); break;
        case 2: _t->handleFireUpdate((*reinterpret_cast< std::add_pointer_t<vector<string>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 3: _t->handleRatiosUpdates((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 4: _t->onButtonClicked(); break;
        case 5: _t->onFileAddActionTriggered(); break;
        case 6: _t->on_linemsall_returnPressed(); break;
        case 7: _t->on_runButtonMain_clicked(); break;
        case 8: _t->on_pauseButtonMain_clicked(); break;
        case 9: _t->on_instantButtonMain_clicked(); break;
        case 10: _t->on_pushButton_clicked(); break;
        case 11: _t->on_pushButton_2_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
