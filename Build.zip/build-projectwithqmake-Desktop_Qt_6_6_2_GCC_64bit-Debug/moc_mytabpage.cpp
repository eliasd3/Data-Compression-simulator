/****************************************************************************
** Meta object code from reading C++ file 'mytabpage.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../projectwithqmake20_04/projectwithqmake/mytabpage.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mytabpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSTabPageENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSTabPageENDCLASS = QtMocHelpers::stringData(
    "TabPage",
    "onPushButtonClicked",
    "",
    "onColumnChoiceCurrentIndexChanged",
    "index",
    "onColumnChoice2CurrentTextChanged",
    "arg1",
    "on_lineEdit_returnPressed",
    "on_spinBox_valueChanged",
    "updateXAxisRange",
    "QCPRange",
    "newRange",
    "updateYAxisRange",
    "onRunButtonClicked",
    "onInstantButtonClicked",
    "onPauseButtonClicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSTabPageENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[8];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[34];
    char stringdata4[6];
    char stringdata5[34];
    char stringdata6[5];
    char stringdata7[26];
    char stringdata8[24];
    char stringdata9[17];
    char stringdata10[9];
    char stringdata11[9];
    char stringdata12[17];
    char stringdata13[19];
    char stringdata14[23];
    char stringdata15[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSTabPageENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSTabPageENDCLASS_t qt_meta_stringdata_CLASSTabPageENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7),  // "TabPage"
        QT_MOC_LITERAL(8, 19),  // "onPushButtonClicked"
        QT_MOC_LITERAL(28, 0),  // ""
        QT_MOC_LITERAL(29, 33),  // "onColumnChoiceCurrentIndexCha..."
        QT_MOC_LITERAL(63, 5),  // "index"
        QT_MOC_LITERAL(69, 33),  // "onColumnChoice2CurrentTextCha..."
        QT_MOC_LITERAL(103, 4),  // "arg1"
        QT_MOC_LITERAL(108, 25),  // "on_lineEdit_returnPressed"
        QT_MOC_LITERAL(134, 23),  // "on_spinBox_valueChanged"
        QT_MOC_LITERAL(158, 16),  // "updateXAxisRange"
        QT_MOC_LITERAL(175, 8),  // "QCPRange"
        QT_MOC_LITERAL(184, 8),  // "newRange"
        QT_MOC_LITERAL(193, 16),  // "updateYAxisRange"
        QT_MOC_LITERAL(210, 18),  // "onRunButtonClicked"
        QT_MOC_LITERAL(229, 22),  // "onInstantButtonClicked"
        QT_MOC_LITERAL(252, 20)   // "onPauseButtonClicked"
    },
    "TabPage",
    "onPushButtonClicked",
    "",
    "onColumnChoiceCurrentIndexChanged",
    "index",
    "onColumnChoice2CurrentTextChanged",
    "arg1",
    "on_lineEdit_returnPressed",
    "on_spinBox_valueChanged",
    "updateXAxisRange",
    "QCPRange",
    "newRange",
    "updateYAxisRange",
    "onRunButtonClicked",
    "onInstantButtonClicked",
    "onPauseButtonClicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSTabPageENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x08,    1 /* Private */,
       3,    1,   75,    2, 0x08,    2 /* Private */,
       5,    1,   78,    2, 0x08,    4 /* Private */,
       7,    0,   81,    2, 0x08,    6 /* Private */,
       8,    1,   82,    2, 0x08,    7 /* Private */,
       9,    1,   85,    2, 0x08,    9 /* Private */,
      12,    1,   88,    2, 0x08,   11 /* Private */,
      13,    0,   91,    2, 0x0a,   13 /* Public */,
      14,    0,   92,    2, 0x0a,   14 /* Public */,
      15,    0,   93,    2, 0x0a,   15 /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject TabPage::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSTabPageENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSTabPageENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSTabPageENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<TabPage, std::true_type>,
        // method 'onPushButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onColumnChoiceCurrentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'onColumnChoice2CurrentTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_lineEdit_returnPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_spinBox_valueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'updateXAxisRange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QCPRange &, std::false_type>,
        // method 'updateYAxisRange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QCPRange &, std::false_type>,
        // method 'onRunButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onInstantButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onPauseButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void TabPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TabPage *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onPushButtonClicked(); break;
        case 1: _t->onColumnChoiceCurrentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->onColumnChoice2CurrentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->on_lineEdit_returnPressed(); break;
        case 4: _t->on_spinBox_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->updateXAxisRange((*reinterpret_cast< std::add_pointer_t<QCPRange>>(_a[1]))); break;
        case 6: _t->updateYAxisRange((*reinterpret_cast< std::add_pointer_t<QCPRange>>(_a[1]))); break;
        case 7: _t->onRunButtonClicked(); break;
        case 8: _t->onInstantButtonClicked(); break;
        case 9: _t->onPauseButtonClicked(); break;
        default: ;
        }
    }
}

const QMetaObject *TabPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TabPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSTabPageENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TabPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
