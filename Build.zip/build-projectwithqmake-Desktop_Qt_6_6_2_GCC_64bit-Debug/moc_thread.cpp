/****************************************************************************
** Meta object code from reading C++ file 'thread.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../projectwithqmake20_04/projectwithqmake/thread.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'thread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMyThreadENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMyThreadENDCLASS = QtMocHelpers::stringData(
    "MyThread",
    "compressedDataUpdate",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "tabNumber",
    "HuffmanDataUpdate",
    "vector<string>",
    "encodedValues"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMyThreadENDCLASS_t {
    uint offsetsAndSizes[20];
    char stringdata0[9];
    char stringdata1[21];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[11];
    char stringdata5[15];
    char stringdata6[10];
    char stringdata7[18];
    char stringdata8[15];
    char stringdata9[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMyThreadENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMyThreadENDCLASS_t qt_meta_stringdata_CLASSMyThreadENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "MyThread"
        QT_MOC_LITERAL(9, 20),  // "compressedDataUpdate"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 14),  // "vector<double>"
        QT_MOC_LITERAL(46, 10),  // "dataStream"
        QT_MOC_LITERAL(57, 14),  // "compressedData"
        QT_MOC_LITERAL(72, 9),  // "tabNumber"
        QT_MOC_LITERAL(82, 17),  // "HuffmanDataUpdate"
        QT_MOC_LITERAL(100, 14),  // "vector<string>"
        QT_MOC_LITERAL(115, 13)   // "encodedValues"
    },
    "MyThread",
    "compressedDataUpdate",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "tabNumber",
    "HuffmanDataUpdate",
    "vector<string>",
    "encodedValues"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMyThreadENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,   26,    2, 0x06,    1 /* Public */,
       7,    4,   33,    2, 0x06,    5 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3, QMetaType::Int,    4,    5,    6,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 8, 0x80000000 | 3, QMetaType::Int,    4,    5,    9,    6,

       0        // eod
};

Q_CONSTINIT const QMetaObject MyThread::staticMetaObject = { {
    QMetaObject::SuperData::link<QThread::staticMetaObject>(),
    qt_meta_stringdata_CLASSMyThreadENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMyThreadENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMyThreadENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MyThread, std::true_type>,
        // method 'compressedDataUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'HuffmanDataUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<string>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void MyThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MyThread *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->compressedDataUpdate((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 1: _t->HuffmanDataUpdate((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<string>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[4]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MyThread::*)(vector<double> , vector<double> , int );
            if (_t _q_method = &MyThread::compressedDataUpdate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MyThread::*)(vector<double> , vector<string> , vector<double> , int );
            if (_t _q_method = &MyThread::HuffmanDataUpdate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *MyThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMyThreadENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int MyThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void MyThread::compressedDataUpdate(vector<double> _t1, vector<double> _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MyThread::HuffmanDataUpdate(vector<double> _t1, vector<string> _t2, vector<double> _t3, int _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
