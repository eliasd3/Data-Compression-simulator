/********************************************************************************
** Form generated from reading UI file 'plotpertab.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLOTPERTAB_H
#define UI_PLOTPERTAB_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_plotPerTab
{
public:
    QGridLayout *gridLayout;
    QFrame *frame_2;
    QGridLayout *gridLayout_2;
    QLabel *labelOriginal;
    QLabel *labelCompressed;
    QLabel *labelDecompressed;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QWidget *horizontalWidget;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelResults;
    QSpacerItem *verticalSpacer;
    QLabel *label_2;
    QWidget *horizontalWidget_2;
    QHBoxLayout *horizontalLayout;
    QLabel *compressedTime;
    QLabel *label_6;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_4;
    QWidget *horizontalWidget_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *DecompressedTime;
    QLabel *label_7;
    QCustomPlot *dataplot;
    QCustomPlot *compressedplot;
    QCustomPlot *decompressedplot;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_5;
    QGridLayout *gridLayout_3;
    QLabel *compressedDataView;

    void setupUi(QWidget *plotPerTab)
    {
        if (plotPerTab->objectName().isEmpty())
            plotPerTab->setObjectName("plotPerTab");
        plotPerTab->resize(893, 240);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(plotPerTab->sizePolicy().hasHeightForWidth());
        plotPerTab->setSizePolicy(sizePolicy);
        plotPerTab->setMinimumSize(QSize(0, 240));
        plotPerTab->setMaximumSize(QSize(10000, 240));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(255, 255, 255, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        palette.setBrush(QPalette::Active, QPalette::Light, brush1);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush1);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush1);
        QBrush brush2(QColor(255, 255, 220, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush3(QColor(0, 0, 0, 127));
        brush3.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush3);
#endif
        palette.setBrush(QPalette::Active, QPalette::Accent, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush3);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::Accent, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        QBrush brush4(QColor(127, 127, 127, 127));
        brush4.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush4);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::Accent, brush1);
        plotPerTab->setPalette(palette);
        plotPerTab->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        gridLayout = new QGridLayout(plotPerTab);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        frame_2 = new QFrame(plotPerTab);
        frame_2->setObjectName("frame_2");
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        gridLayout_2 = new QGridLayout(frame_2);
        gridLayout_2->setObjectName("gridLayout_2");
        labelOriginal = new QLabel(frame_2);
        labelOriginal->setObjectName("labelOriginal");
        labelOriginal->setMinimumSize(QSize(150, 0));
        labelOriginal->setMaximumSize(QSize(16777215, 20));

        gridLayout_2->addWidget(labelOriginal, 0, 0, 1, 1);

        labelCompressed = new QLabel(frame_2);
        labelCompressed->setObjectName("labelCompressed");
        labelCompressed->setMinimumSize(QSize(150, 0));

        gridLayout_2->addWidget(labelCompressed, 0, 1, 1, 1);

        labelDecompressed = new QLabel(frame_2);
        labelDecompressed->setObjectName("labelDecompressed");
        labelDecompressed->setMinimumSize(QSize(150, 0));

        gridLayout_2->addWidget(labelDecompressed, 0, 2, 1, 1);

        frame = new QFrame(frame_2);
        frame->setObjectName("frame");
        frame->setFrameShape(QFrame::Box);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setObjectName("verticalLayout");
        label = new QLabel(frame);
        label->setObjectName("label");
        label->setMinimumSize(QSize(0, 0));
        label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";"));

        verticalLayout->addWidget(label);

        horizontalWidget = new QWidget(frame);
        horizontalWidget->setObjectName("horizontalWidget");
        horizontalLayout_3 = new QHBoxLayout(horizontalWidget);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        labelResults = new QLabel(horizontalWidget);
        labelResults->setObjectName("labelResults");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labelResults->sizePolicy().hasHeightForWidth());
        labelResults->setSizePolicy(sizePolicy1);
        labelResults->setMinimumSize(QSize(0, 0));

        horizontalLayout_3->addWidget(labelResults);


        verticalLayout->addWidget(horizontalWidget);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        label_2 = new QLabel(frame);
        label_2->setObjectName("label_2");
        label_2->setMinimumSize(QSize(0, 0));
        label_2->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";"));

        verticalLayout->addWidget(label_2);

        horizontalWidget_2 = new QWidget(frame);
        horizontalWidget_2->setObjectName("horizontalWidget_2");
        horizontalWidget_2->setMinimumSize(QSize(0, 0));
        horizontalLayout = new QHBoxLayout(horizontalWidget_2);
        horizontalLayout->setObjectName("horizontalLayout");
        compressedTime = new QLabel(horizontalWidget_2);
        compressedTime->setObjectName("compressedTime");
        compressedTime->setMinimumSize(QSize(0, 0));

        horizontalLayout->addWidget(compressedTime);

        label_6 = new QLabel(horizontalWidget_2);
        label_6->setObjectName("label_6");
        label_6->setMaximumSize(QSize(20, 16777215));

        horizontalLayout->addWidget(label_6);


        verticalLayout->addWidget(horizontalWidget_2);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        label_4 = new QLabel(frame);
        label_4->setObjectName("label_4");
        label_4->setMinimumSize(QSize(0, 0));
        label_4->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";"));

        verticalLayout->addWidget(label_4);

        horizontalWidget_3 = new QWidget(frame);
        horizontalWidget_3->setObjectName("horizontalWidget_3");
        horizontalWidget_3->setMinimumSize(QSize(0, 0));
        horizontalWidget_3->setMaximumSize(QSize(16777215, 11111111));
        horizontalLayout_2 = new QHBoxLayout(horizontalWidget_3);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        DecompressedTime = new QLabel(horizontalWidget_3);
        DecompressedTime->setObjectName("DecompressedTime");
        DecompressedTime->setMinimumSize(QSize(0, 0));

        horizontalLayout_2->addWidget(DecompressedTime);

        label_7 = new QLabel(horizontalWidget_3);
        label_7->setObjectName("label_7");
        label_7->setMinimumSize(QSize(0, 0));
        label_7->setMaximumSize(QSize(20, 30));

        horizontalLayout_2->addWidget(label_7);


        verticalLayout->addWidget(horizontalWidget_3);


        gridLayout_2->addWidget(frame, 0, 3, 3, 1);

        dataplot = new QCustomPlot(frame_2);
        dataplot->setObjectName("dataplot");

        gridLayout_2->addWidget(dataplot, 1, 0, 1, 1);

        compressedplot = new QCustomPlot(frame_2);
        compressedplot->setObjectName("compressedplot");

        gridLayout_2->addWidget(compressedplot, 1, 1, 1, 1);

        decompressedplot = new QCustomPlot(frame_2);
        decompressedplot->setObjectName("decompressedplot");

        gridLayout_2->addWidget(decompressedplot, 1, 2, 1, 1);

        scrollArea = new QScrollArea(frame_2);
        scrollArea->setObjectName("scrollArea");
        scrollArea->setEnabled(true);
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(scrollArea->sizePolicy().hasHeightForWidth());
        scrollArea->setSizePolicy(sizePolicy2);
        scrollArea->setMaximumSize(QSize(16777215, 43));
        scrollArea->setLayoutDirection(Qt::RightToLeft);
        scrollArea->setStyleSheet(QString::fromUtf8("QScrollBar:horizontal {\n"
"    height: 12px;\n"
"    border-radius: 3px;\n"
"    background-color: rgb(222, 221, 218);  \n"
"	margin: 3px;\n"
"}\n"
"\n"
"QScrollBar::handle:horizontal {\n"
"    background-color: green;   \n"
"    min-width: 4px;\n"
"    border-radius: 3px;\n"
"}\n"
"\n"
"QScrollBar::handle:horizontal:hover {\n"
"    background-color: rgb(113, 184, 101);\n"
"}\n"
"\n"
"QScrollBar::sub-line:horizontal,\n"
"QScrollBar::add-line:horizontal {\n"
"    height: 0;\n"
"    width: 0;\n"
"    subcontrol-position: bottom;\n"
"    subcontrol-origin: margin;\n"
"}"));
        scrollArea->setFrameShape(QFrame::StyledPanel);
        scrollArea->setFrameShadow(QFrame::Plain);
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName("scrollAreaWidgetContents_5");
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 651, 41));
        gridLayout_3 = new QGridLayout(scrollAreaWidgetContents_5);
        gridLayout_3->setObjectName("gridLayout_3");
        compressedDataView = new QLabel(scrollAreaWidgetContents_5);
        compressedDataView->setObjectName("compressedDataView");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(compressedDataView->sizePolicy().hasHeightForWidth());
        compressedDataView->setSizePolicy(sizePolicy3);
        compressedDataView->setMaximumSize(QSize(16777215, 11));
        compressedDataView->setLayoutDirection(Qt::RightToLeft);
        compressedDataView->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        compressedDataView->setWordWrap(false);

        gridLayout_3->addWidget(compressedDataView, 0, 0, 1, 1);

        scrollArea->setWidget(scrollAreaWidgetContents_5);

        gridLayout_2->addWidget(scrollArea, 2, 0, 1, 3);


        gridLayout->addWidget(frame_2, 0, 0, 1, 1);


        retranslateUi(plotPerTab);

        QMetaObject::connectSlotsByName(plotPerTab);
    } // setupUi

    void retranslateUi(QWidget *plotPerTab)
    {
        plotPerTab->setWindowTitle(QCoreApplication::translate("plotPerTab", "Form", nullptr));
        labelOriginal->setText(QCoreApplication::translate("plotPerTab", "Original data:", nullptr));
        labelCompressed->setText(QCoreApplication::translate("plotPerTab", "Compressed data:", nullptr));
        labelDecompressed->setText(QCoreApplication::translate("plotPerTab", "Decompressed data:", nullptr));
        label->setText(QCoreApplication::translate("plotPerTab", "Compression Ratio:", nullptr));
        labelResults->setText(QCoreApplication::translate("plotPerTab", "1", nullptr));
        label_2->setText(QCoreApplication::translate("plotPerTab", "Compress time:", nullptr));
        compressedTime->setText(QString());
        label_6->setText(QCoreApplication::translate("plotPerTab", "\302\265s", nullptr));
        label_4->setText(QCoreApplication::translate("plotPerTab", "Decompress time:", nullptr));
        DecompressedTime->setText(QString());
        label_7->setText(QCoreApplication::translate("plotPerTab", "\302\265s", nullptr));
        compressedDataView->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class plotPerTab: public Ui_plotPerTab {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLOTPERTAB_H
