/****************************************************************************
** Meta object code from reading C++ file 'mythread.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../projectMaster/mythread.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mythread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSThreadENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSThreadENDCLASS = QtMocHelpers::stringData(
    "Thread",
    "deltaCompressedDataUpdate",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "decodedValues",
    "tabNumber",
    "HuffmanDataUpdate",
    "vector<string>",
    "encodedValues",
    "fireDataUpdate",
    "ratiosUpdates",
    "ratio1"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSThreadENDCLASS_t {
    uint offsetsAndSizes[28];
    char stringdata0[7];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[15];
    char stringdata4[11];
    char stringdata5[15];
    char stringdata6[14];
    char stringdata7[10];
    char stringdata8[18];
    char stringdata9[15];
    char stringdata10[14];
    char stringdata11[15];
    char stringdata12[14];
    char stringdata13[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSThreadENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSThreadENDCLASS_t qt_meta_stringdata_CLASSThreadENDCLASS = {
    {
        QT_MOC_LITERAL(0, 6),  // "Thread"
        QT_MOC_LITERAL(7, 25),  // "deltaCompressedDataUpdate"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 14),  // "vector<double>"
        QT_MOC_LITERAL(49, 10),  // "dataStream"
        QT_MOC_LITERAL(60, 14),  // "compressedData"
        QT_MOC_LITERAL(75, 13),  // "decodedValues"
        QT_MOC_LITERAL(89, 9),  // "tabNumber"
        QT_MOC_LITERAL(99, 17),  // "HuffmanDataUpdate"
        QT_MOC_LITERAL(117, 14),  // "vector<string>"
        QT_MOC_LITERAL(132, 13),  // "encodedValues"
        QT_MOC_LITERAL(146, 14),  // "fireDataUpdate"
        QT_MOC_LITERAL(161, 13),  // "ratiosUpdates"
        QT_MOC_LITERAL(175, 6)   // "ratio1"
    },
    "Thread",
    "deltaCompressedDataUpdate",
    "",
    "vector<double>",
    "dataStream",
    "compressedData",
    "decodedValues",
    "tabNumber",
    "HuffmanDataUpdate",
    "vector<string>",
    "encodedValues",
    "fireDataUpdate",
    "ratiosUpdates",
    "ratio1"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSThreadENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    4,   38,    2, 0x06,    1 /* Public */,
       8,    5,   47,    2, 0x06,    6 /* Public */,
      11,    2,   58,    2, 0x06,   12 /* Public */,
      12,    2,   63,    2, 0x06,   15 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3, 0x80000000 | 3, QMetaType::Int,    4,    5,    6,    7,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 9, 0x80000000 | 3, 0x80000000 | 3, QMetaType::Int,    4,    5,   10,    6,    7,
    QMetaType::Void, 0x80000000 | 9, QMetaType::Int,    5,    7,
    QMetaType::Void, QMetaType::Double, QMetaType::Int,   13,    7,

       0        // eod
};

Q_CONSTINIT const QMetaObject Thread::staticMetaObject = { {
    QMetaObject::SuperData::link<QThread::staticMetaObject>(),
    qt_meta_stringdata_CLASSThreadENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSThreadENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSThreadENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Thread, std::true_type>,
        // method 'deltaCompressedDataUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'HuffmanDataUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<string>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<double>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'fireDataUpdate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<vector<string>, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'ratiosUpdates'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void Thread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Thread *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->deltaCompressedDataUpdate((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[4]))); break;
        case 1: _t->HuffmanDataUpdate((*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<vector<string>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<vector<double>>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[5]))); break;
        case 2: _t->fireDataUpdate((*reinterpret_cast< std::add_pointer_t<vector<string>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 3: _t->ratiosUpdates((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Thread::*)(vector<double> , vector<double> , vector<double> , int );
            if (_t _q_method = &Thread::deltaCompressedDataUpdate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Thread::*)(vector<double> , vector<string> , vector<double> , vector<double> , int );
            if (_t _q_method = &Thread::HuffmanDataUpdate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Thread::*)(vector<string> , int );
            if (_t _q_method = &Thread::fireDataUpdate; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Thread::*)(double , int );
            if (_t _q_method = &Thread::ratiosUpdates; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject *Thread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Thread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSThreadENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int Thread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void Thread::deltaCompressedDataUpdate(vector<double> _t1, vector<double> _t2, vector<double> _t3, int _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Thread::HuffmanDataUpdate(vector<double> _t1, vector<string> _t2, vector<double> _t3, vector<double> _t4, int _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Thread::fireDataUpdate(vector<string> _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Thread::ratiosUpdates(double _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
