/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionscreenshot;
    QAction *actionsave_as_jpg;
    QAction *actionabout;
    QAction *fileAddAction;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QTabWidget *myTabWidget;
    QSpacerItem *verticalSpacer;
    QFrame *line;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_8;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *linemsall;
    QLabel *labelmsAll;
    QLabel *label_7;
    QPushButton *runButtonMain;
    QPushButton *pauseButtonMain;
    QPushButton *instantButtonMain;
    QFrame *line_2;
    QScrollArea *scrollAreaPlots;
    QWidget *scrollAreaWidgetContents_5;
    QPushButton *pushButton;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1033, 470);
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(250, 249, 248, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(252, 252, 251, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(125, 125, 124, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(167, 166, 165, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Active, QPalette::Text, brush);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Active, QPalette::Base, brush2);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush3);
        QBrush brush6(QColor(255, 255, 220, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush);
        QBrush brush7(QColor(0, 0, 0, 127));
        brush7.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush7);
#endif
        palette.setBrush(QPalette::Active, QPalette::Accent, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush7);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::Accent, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush);
        QBrush brush8(QColor(125, 125, 124, 127));
        brush8.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush8);
#endif
        palette.setBrush(QPalette::Disabled, QPalette::Accent, brush2);
        MainWindow->setPalette(palette);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        MainWindow->setAnimated(true);
        MainWindow->setTabShape(QTabWidget::Rounded);
        actionscreenshot = new QAction(MainWindow);
        actionscreenshot->setObjectName("actionscreenshot");
        actionsave_as_jpg = new QAction(MainWindow);
        actionsave_as_jpg->setObjectName("actionsave_as_jpg");
        actionabout = new QAction(MainWindow);
        actionabout->setObjectName("actionabout");
        fileAddAction = new QAction(MainWindow);
        fileAddAction->setObjectName("fileAddAction");
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName("gridLayout");
        widget = new QWidget(centralwidget);
        widget->setObjectName("widget");
        widget->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy1);
        widget->setMaximumSize(QSize(200, 16777215));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        myTabWidget = new QTabWidget(widget);
        myTabWidget->setObjectName("myTabWidget");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Ignored, QSizePolicy::Policy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(myTabWidget->sizePolicy().hasHeightForWidth());
        myTabWidget->setSizePolicy(sizePolicy2);
        myTabWidget->setMinimumSize(QSize(180, 0));
        myTabWidget->setMaximumSize(QSize(198, 16777215));
        myTabWidget->setAutoFillBackground(false);

        verticalLayout_3->addWidget(myTabWidget);

        verticalSpacer = new QSpacerItem(20, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        verticalLayout_3->addItem(verticalSpacer);

        line = new QFrame(widget);
        line->setObjectName("line");
        line->setMaximumSize(QSize(198, 16777215));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_3->addWidget(line);

        verticalSpacer_2 = new QSpacerItem(20, 5, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        verticalLayout_3->addItem(verticalSpacer_2);

        label_8 = new QLabel(widget);
        label_8->setObjectName("label_8");
        label_8->setMaximumSize(QSize(198, 16777215));

        verticalLayout_3->addWidget(label_8);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName("verticalLayout_4");
        verticalLayout_4->setContentsMargins(6, -1, 6, -1);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        horizontalLayout_3->setSizeConstraint(QLayout::SetMaximumSize);
        linemsall = new QLineEdit(widget);
        linemsall->setObjectName("linemsall");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(linemsall->sizePolicy().hasHeightForWidth());
        linemsall->setSizePolicy(sizePolicy3);
        linemsall->setMaximumSize(QSize(82, 16777215));

        horizontalLayout_3->addWidget(linemsall);

        labelmsAll = new QLabel(widget);
        labelmsAll->setObjectName("labelmsAll");
        labelmsAll->setMinimumSize(QSize(70, 0));
        labelmsAll->setMaximumSize(QSize(70, 16777215));
        labelmsAll->setLayoutDirection(Qt::LeftToRight);
        labelmsAll->setStyleSheet(QString::fromUtf8("color: rgb(94, 92, 100);"));
        labelmsAll->setLineWidth(0);
        labelmsAll->setMidLineWidth(0);
        labelmsAll->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(labelmsAll);

        label_7 = new QLabel(widget);
        label_7->setObjectName("label_7");
        label_7->setMaximumSize(QSize(20, 16777215));
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(94, 92, 100);"));

        horizontalLayout_3->addWidget(label_7);


        verticalLayout_4->addLayout(horizontalLayout_3);

        runButtonMain = new QPushButton(widget);
        runButtonMain->setObjectName("runButtonMain");
        runButtonMain->setMaximumSize(QSize(186, 16777215));
        runButtonMain->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));
        runButtonMain->setCheckable(false);

        verticalLayout_4->addWidget(runButtonMain);

        pauseButtonMain = new QPushButton(widget);
        pauseButtonMain->setObjectName("pauseButtonMain");
        pauseButtonMain->setMaximumSize(QSize(186, 16777215));
        pauseButtonMain->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));
        pauseButtonMain->setCheckable(false);

        verticalLayout_4->addWidget(pauseButtonMain);

        instantButtonMain = new QPushButton(widget);
        instantButtonMain->setObjectName("instantButtonMain");
        instantButtonMain->setMaximumSize(QSize(186, 16777215));
        instantButtonMain->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));
        instantButtonMain->setCheckable(false);

        verticalLayout_4->addWidget(instantButtonMain);


        verticalLayout_3->addLayout(verticalLayout_4);


        gridLayout->addWidget(widget, 0, 0, 2, 1);

        line_2 = new QFrame(centralwidget);
        line_2->setObjectName("line_2");
        line_2->setMaximumSize(QSize(3, 16777215));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        gridLayout->addWidget(line_2, 0, 1, 1, 1);

        scrollAreaPlots = new QScrollArea(centralwidget);
        scrollAreaPlots->setObjectName("scrollAreaPlots");
        scrollAreaPlots->setMinimumSize(QSize(800, 0));
        scrollAreaPlots->setStyleSheet(QString::fromUtf8("plotPerTab {\n"
"    background-color: rgb(255, 255, 255);\n"
"}\n"
"QScrollBar:vertical {\n"
"    width: 12px;\n"
"    border-radius: 3px;\n"
"    background-color: rgb(222, 221, 218);  \n"
"	margin: 3px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical {\n"
"    background-color: green;   \n"
"    min-height: 4px;\n"
"    border-radius: 3px;\n"
"}\n"
"\n"
"QScrollBar::handle:vertical:hover {\n"
"    background-color: rgb(113, 184, 101);\n"
"}\n"
"\n"
"QScrollBar::sub-line:vertical,\n"
"QScrollBar::add-line:vertical {\n"
"    height: 0;\n"
"    width: 0;\n"
"    subcontrol-position: bottom;\n"
"    subcontrol-origin: margin;\n"
"}\n"
"\n"
""));
        scrollAreaPlots->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName("scrollAreaWidgetContents_5");
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 798, 382));
        scrollAreaWidgetContents_5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"color: rgb(255, 255, 255);\n"
"alternate-background-color: rgb(255, 255, 255);\n"
"gridline-color: rgb(255, 255, 255);"));
        scrollAreaPlots->setWidget(scrollAreaWidgetContents_5);

        gridLayout->addWidget(scrollAreaPlots, 0, 2, 1, 1);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName("pushButton");
        pushButton->setMinimumSize(QSize(200, 40));
        pushButton->setMaximumSize(QSize(200, 16777215));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));

        gridLayout->addWidget(pushButton, 1, 2, 1, 1, Qt::AlignRight);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        myTabWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionscreenshot->setText(QCoreApplication::translate("MainWindow", "save as png", nullptr));
        actionsave_as_jpg->setText(QCoreApplication::translate("MainWindow", "save as jpg", nullptr));
        actionabout->setText(QCoreApplication::translate("MainWindow", "about", nullptr));
        fileAddAction->setText(QCoreApplication::translate("MainWindow", "add txt file", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Config All Datastreams:", nullptr));
        linemsall->setText(QString());
        labelmsAll->setText(QCoreApplication::translate("MainWindow", "60", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "ms", nullptr));
        runButtonMain->setText(QCoreApplication::translate("MainWindow", "Run all", nullptr));
        pauseButtonMain->setText(QCoreApplication::translate("MainWindow", "Pause/Resume all", nullptr));
        instantButtonMain->setText(QCoreApplication::translate("MainWindow", "Speed all", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Export", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
