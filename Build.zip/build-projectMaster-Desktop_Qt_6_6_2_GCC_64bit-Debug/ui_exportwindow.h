/********************************************************************************
** Form generated from reading UI file 'exportwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EXPORTWINDOW_H
#define UI_EXPORTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_exportWindow
{
public:
    QHBoxLayout *horizontalLayout_4;
    QFrame *formFrame;
    QFormLayout *formLayout;
    QFrame *verticalFrame;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_13;
    QHBoxLayout *horizontalLayout_3;
    QPlainTextEdit *plainTextEdit;
    QLabel *label;
    QFrame *line;
    QLabel *label_2;
    QLineEdit *CruisEdit;
    QLabel *label_3;
    QLineEdit *StationEdit;
    QLabel *label_4;
    QLineEdit *TypeEdit;
    QLabel *label_5;
    QLineEdit *DateEdit;
    QLabel *label_6;
    QLineEdit *LongitudeEdit;
    QLabel *label_7;
    QLineEdit *LatitudeEdit;
    QLabel *label_8;
    QLineEdit *LocalEdit;
    QLabel *label_9;
    QLineEdit *EDMOEdit;
    QLabel *label_10;
    QLineEdit *BotDepthEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelDirectory;
    QPushButton *pushButton;

    void setupUi(QWidget *exportWindow)
    {
        if (exportWindow->objectName().isEmpty())
            exportWindow->setObjectName("exportWindow");
        exportWindow->resize(614, 499);
        exportWindow->setStyleSheet(QString::fromUtf8("background-color: white;"));
        horizontalLayout_4 = new QHBoxLayout(exportWindow);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        formFrame = new QFrame(exportWindow);
        formFrame->setObjectName("formFrame");
        formFrame->setFrameShape(QFrame::Box);
        formFrame->setFrameShadow(QFrame::Raised);
        formLayout = new QFormLayout(formFrame);
        formLayout->setObjectName("formLayout");
        verticalFrame = new QFrame(formFrame);
        verticalFrame->setObjectName("verticalFrame");
        verticalFrame->setFrameShape(QFrame::Box);
        verticalFrame->setFrameShadow(QFrame::Raised);
        verticalLayout_2 = new QVBoxLayout(verticalFrame);
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_13 = new QLabel(verticalFrame);
        label_13->setObjectName("label_13");
        label_13->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";"));

        verticalLayout_2->addWidget(label_13);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        plainTextEdit = new QPlainTextEdit(verticalFrame);
        plainTextEdit->setObjectName("plainTextEdit");

        horizontalLayout_3->addWidget(plainTextEdit);


        verticalLayout_2->addLayout(horizontalLayout_3);


        formLayout->setWidget(0, QFormLayout::SpanningRole, verticalFrame);

        label = new QLabel(formFrame);
        label->setObjectName("label");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Preferred, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setStyleSheet(QString::fromUtf8("font: 500 11pt \"Ubuntu\";"));

        formLayout->setWidget(1, QFormLayout::SpanningRole, label);

        line = new QFrame(formFrame);
        line->setObjectName("line");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(1);
        sizePolicy1.setHeightForWidth(line->sizePolicy().hasHeightForWidth());
        line->setSizePolicy(sizePolicy1);
        line->setMinimumSize(QSize(0, 1));
        line->setBaseSize(QSize(0, 1));
        line->setAcceptDrops(false);
        line->setAutoFillBackground(false);
        line->setStyleSheet(QString::fromUtf8("color: rgb(192, 191, 188);\n"
"gridline-color: rgb(154, 153, 150);\n"
"border-color: rgb(192, 191, 188);"));
        line->setMidLineWidth(1);
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        formLayout->setWidget(2, QFormLayout::LabelRole, line);

        label_2 = new QLabel(formFrame);
        label_2->setObjectName("label_2");

        formLayout->setWidget(3, QFormLayout::LabelRole, label_2);

        CruisEdit = new QLineEdit(formFrame);
        CruisEdit->setObjectName("CruisEdit");
        QSizePolicy sizePolicy2(QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(CruisEdit->sizePolicy().hasHeightForWidth());
        CruisEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(3, QFormLayout::FieldRole, CruisEdit);

        label_3 = new QLabel(formFrame);
        label_3->setObjectName("label_3");

        formLayout->setWidget(4, QFormLayout::LabelRole, label_3);

        StationEdit = new QLineEdit(formFrame);
        StationEdit->setObjectName("StationEdit");
        sizePolicy2.setHeightForWidth(StationEdit->sizePolicy().hasHeightForWidth());
        StationEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(4, QFormLayout::FieldRole, StationEdit);

        label_4 = new QLabel(formFrame);
        label_4->setObjectName("label_4");

        formLayout->setWidget(5, QFormLayout::LabelRole, label_4);

        TypeEdit = new QLineEdit(formFrame);
        TypeEdit->setObjectName("TypeEdit");
        sizePolicy2.setHeightForWidth(TypeEdit->sizePolicy().hasHeightForWidth());
        TypeEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(5, QFormLayout::FieldRole, TypeEdit);

        label_5 = new QLabel(formFrame);
        label_5->setObjectName("label_5");

        formLayout->setWidget(6, QFormLayout::LabelRole, label_5);

        DateEdit = new QLineEdit(formFrame);
        DateEdit->setObjectName("DateEdit");
        sizePolicy2.setHeightForWidth(DateEdit->sizePolicy().hasHeightForWidth());
        DateEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(6, QFormLayout::FieldRole, DateEdit);

        label_6 = new QLabel(formFrame);
        label_6->setObjectName("label_6");

        formLayout->setWidget(7, QFormLayout::LabelRole, label_6);

        LongitudeEdit = new QLineEdit(formFrame);
        LongitudeEdit->setObjectName("LongitudeEdit");
        sizePolicy2.setHeightForWidth(LongitudeEdit->sizePolicy().hasHeightForWidth());
        LongitudeEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(7, QFormLayout::FieldRole, LongitudeEdit);

        label_7 = new QLabel(formFrame);
        label_7->setObjectName("label_7");

        formLayout->setWidget(8, QFormLayout::LabelRole, label_7);

        LatitudeEdit = new QLineEdit(formFrame);
        LatitudeEdit->setObjectName("LatitudeEdit");
        sizePolicy2.setHeightForWidth(LatitudeEdit->sizePolicy().hasHeightForWidth());
        LatitudeEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(8, QFormLayout::FieldRole, LatitudeEdit);

        label_8 = new QLabel(formFrame);
        label_8->setObjectName("label_8");

        formLayout->setWidget(9, QFormLayout::LabelRole, label_8);

        LocalEdit = new QLineEdit(formFrame);
        LocalEdit->setObjectName("LocalEdit");
        sizePolicy2.setHeightForWidth(LocalEdit->sizePolicy().hasHeightForWidth());
        LocalEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(9, QFormLayout::FieldRole, LocalEdit);

        label_9 = new QLabel(formFrame);
        label_9->setObjectName("label_9");

        formLayout->setWidget(10, QFormLayout::LabelRole, label_9);

        EDMOEdit = new QLineEdit(formFrame);
        EDMOEdit->setObjectName("EDMOEdit");
        sizePolicy2.setHeightForWidth(EDMOEdit->sizePolicy().hasHeightForWidth());
        EDMOEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(10, QFormLayout::FieldRole, EDMOEdit);

        label_10 = new QLabel(formFrame);
        label_10->setObjectName("label_10");

        formLayout->setWidget(11, QFormLayout::LabelRole, label_10);

        BotDepthEdit = new QLineEdit(formFrame);
        BotDepthEdit->setObjectName("BotDepthEdit");
        sizePolicy2.setHeightForWidth(BotDepthEdit->sizePolicy().hasHeightForWidth());
        BotDepthEdit->setSizePolicy(sizePolicy2);

        formLayout->setWidget(11, QFormLayout::FieldRole, BotDepthEdit);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        labelDirectory = new QLabel(formFrame);
        labelDirectory->setObjectName("labelDirectory");

        horizontalLayout_2->addWidget(labelDirectory);

        pushButton = new QPushButton(formFrame);
        pushButton->setObjectName("pushButton");
        QSizePolicy sizePolicy3(QSizePolicy::Policy::Maximum, QSizePolicy::Policy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy3);
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(0,111,60);\n"
"color: black; \n"
""));

        horizontalLayout_2->addWidget(pushButton);


        formLayout->setLayout(12, QFormLayout::SpanningRole, horizontalLayout_2);


        horizontalLayout_4->addWidget(formFrame);


        retranslateUi(exportWindow);

        QMetaObject::connectSlotsByName(exportWindow);
    } // setupUi

    void retranslateUi(QWidget *exportWindow)
    {
        exportWindow->setWindowTitle(QCoreApplication::translate("exportWindow", "Form", nullptr));
        label_13->setText(QCoreApplication::translate("exportWindow", "Extra comment lines:          ", nullptr));
        plainTextEdit->setPlainText(QCoreApplication::translate("exportWindow", "//", nullptr));
        label->setText(QCoreApplication::translate("exportWindow", "Fill in Metadata:", nullptr));
        label_2->setText(QCoreApplication::translate("exportWindow", "Cruise", nullptr));
        label_3->setText(QCoreApplication::translate("exportWindow", "Station", nullptr));
        label_4->setText(QCoreApplication::translate("exportWindow", "Type", nullptr));
        label_5->setText(QCoreApplication::translate("exportWindow", "yyyy-mm-ddThh:mm:ss.sss", nullptr));
        DateEdit->setText(QString());
        label_6->setText(QCoreApplication::translate("exportWindow", "Longitude [degrees_east]", nullptr));
        label_7->setText(QCoreApplication::translate("exportWindow", "Latitude [degrees_north]", nullptr));
        label_8->setText(QCoreApplication::translate("exportWindow", "LOCAL_CDI_ID", nullptr));
        label_9->setText(QCoreApplication::translate("exportWindow", "EDMO_code", nullptr));
        label_10->setText(QCoreApplication::translate("exportWindow", "Bot. Depth [m]", nullptr));
        labelDirectory->setText(QString());
        pushButton->setText(QCoreApplication::translate("exportWindow", "export to ODV", nullptr));
    } // retranslateUi

};

namespace Ui {
    class exportWindow: public Ui_exportWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EXPORTWINDOW_H
